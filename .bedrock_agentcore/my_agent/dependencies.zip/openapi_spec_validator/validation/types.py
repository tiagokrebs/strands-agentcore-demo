from typing import Type

from openapi_spec_validator.validation.validators import SpecValidator

SpecValidatorType = Type[SpecValidator]
